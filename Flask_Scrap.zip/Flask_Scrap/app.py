# import the Flask class from the flask module
from flask import Flask, render_template

# create the application object
app = Flask(__name__)

# use decorators to link the function to a url
@app.route('/')
def home():
    return render_template('welcome.html') 
# @app.route('/welcome/')
# def welcome():
#     return render_template('welcome.html')  # render a template

@app.route('/sars-data/')
def render_sars():
    return render_template('sars.html')

@app.route('/stock-euro/')
def render_stock_euro():
    return render_template('stock-euro.html')  

@app.route('/signin/')
def render_signin():
    return render_template('signin.html')        
# start the server with the 'run()' method
if __name__ == '__main__':
    app.run(debug=True)